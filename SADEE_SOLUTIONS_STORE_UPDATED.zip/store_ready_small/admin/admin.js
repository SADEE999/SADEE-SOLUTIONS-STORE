const sb=window.supabase.createClient(window.SUPABASE_URL,window.SUPABASE_ANON_KEY);
const $=id=>document.getElementById(id);
let products=[],orders=[];

$("loginBtn").onclick=async()=>{
  $("loginMsg").textContent="Signing in…";
  const email=$("email").value.trim();
  const password=$("password").value;
  if(!email||!password){$("loginMsg").textContent="Enter your email and password.";return}
  const {error}=await sb.auth.signInWithPassword({email,password});
  if(error){$("loginMsg").textContent=error.message;return}
  await init();
};

$("logout").onclick=()=>sb.auth.signOut().then(()=>location.reload());

async function verifyAdmin(session){
  const email=session?.user?.email;
  if(!email)return false;
  const {data,error}=await sb.from("admin_users").select("email").ilike("email",email).maybeSingle();
  if(error){
    $("loginMsg").textContent="Admin verification failed: "+error.message;
    return false;
  }
  if(!data){
    await sb.auth.signOut();
    $("loginMsg").textContent="This account is not registered as an admin.";
    return false;
  }
  return true;
}

async function init(){
  const {data:{session}}=await sb.auth.getSession();
  if(!session)return;
  const allowed=await verifyAdmin(session);
  if(!allowed){$("login").classList.remove("hidden");$("app").classList.add("hidden");return}
  $("login").classList.add("hidden");
  $("app").classList.remove("hidden");
  await load();
}

sb.auth.onAuthStateChange((event,session)=>{
  if(event==="SIGNED_IN" && session) init();
  if(event==="SIGNED_OUT"){
    $("login").classList.remove("hidden");
    $("app").classList.add("hidden");
  }
});
async function load(){let r=await sb.from("products").select("*").order("created_at",{ascending:false});products=r.data||[];let o=await sb.from("orders").select("*").order("created_at",{ascending:false});orders=o.data||[];render();$("orderCount").textContent=orders.length}
function render(){const q=$("adminSearch").value.toLowerCase();const list=products.filter(p=>(p.name+" "+(p.category||"")).toLowerCase().includes(q));$("count").textContent=products.length;$("activeCount").textContent=products.filter(p=>p.active).length;$("table").innerHTML=list.map(p=>`<div class="product"><img src="${p.image_url||p.image||''}"><div><h3>${esc(p.name)}</h3><div class="muted">${esc(p.category||'')} · Rs.${Number(p.price||0).toLocaleString()} · ${p.active?'Active':'Hidden'}</div></div><div class="actions"><button onclick="edit('${p.id}')">Edit</button><button class="danger" onclick="del('${p.id}')">Delete</button></div></div>`).join("")||"<p class='muted'>No products.</p>";$("orders").innerHTML=orders.map(o=>`<div class="order"><b>${esc(o.product_name)}</b> · Rs.${Number(o.price||0).toLocaleString()}<br><span class="muted">${esc(o.customer_name||'')} · ${esc(o.customer_phone||'')} · ${new Date(o.created_at).toLocaleString()}</span></div>`).join("")||"<p class='muted'>No recorded orders yet.</p>"}
function esc(v){return String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
$("adminSearch").oninput=render;$("newBtn").onclick=()=>openForm();$("close").onclick=()=>$("modal").classList.remove("show");
function openForm(p=null){$("modal").classList.add("show");$("formTitle").textContent=p?"Edit Product":"Add Product";$("pid").value=p?.id||"";$("pname").value=p?.name||"";$("pcat").value=p?.category||"";$("pprice").value=p?.price||"";$("pnote").value=p?.price_note||"";$("pdesc").value=p?.description||"";$("pfeatures").value=(p?.features||[]).join("\n");$("pimageurl").value=p?.image_url||p?.image||"";$("pfeatured").checked=!!p?.featured;$("pactive").checked=p?p.active!==false:true;$("saveMsg").textContent=""}
window.edit=id=>openForm(products.find(p=>p.id===id));
window.del=async id=>{if(!confirm("Delete this product?"))return;const {error}=await sb.from("products").delete().eq("id",id);if(error)alert(error.message);else load()};
$("save").onclick=async()=>{const id=$("pid").value;let image=$("pimageurl").value.trim();const file=$("pimage").files[0];if(file){const path=`${crypto.randomUUID()}-${file.name.replace(/[^a-zA-Z0-9._-]/g,'_')}`;const up=await sb.storage.from("product-media").upload(path,file,{upsert:false});if(up.error){$("saveMsg").textContent=up.error.message;return}image=sb.storage.from("product-media").getPublicUrl(path).data.publicUrl}
const row={name:$("pname").value.trim(),category:$("pcat").value.trim(),price:Number($("pprice").value||0),price_note:$("pnote").value.trim(),description:$("pdesc").value.trim(),features:$("pfeatures").value.split("\n").map(x=>x.trim()).filter(Boolean),image_url:image,featured:$("pfeatured").checked,active:$("pactive").checked};
let r=id?await sb.from("products").update(row).eq("id",id):await sb.from("products").insert(row);if(r.error){$("saveMsg").textContent=r.error.message}else{$("modal").classList.remove("show");load()}}
init();
